import { boards, type Board, type InsertBoard } from "@shared/schema";

export interface IStorage {
  getBoard(id: number): Promise<Board | undefined>;
  createBoard(board: InsertBoard): Promise<Board>;
  updateBoard(id: number, board: Partial<InsertBoard>): Promise<Board | undefined>;
  deleteBoard(id: number): Promise<boolean>;
  getAllBoards(): Promise<Board[]>;
}

export class MemStorage implements IStorage {
  private boards: Map<number, Board>;
  private currentId: number;

  constructor() {
    this.boards = new Map();
    this.currentId = 1;
  }

  async getBoard(id: number): Promise<Board | undefined> {
    return this.boards.get(id);
  }

  async createBoard(insertBoard: InsertBoard): Promise<Board> {
    const id = this.currentId++;
    const board: Board = { ...insertBoard, id };
    this.boards.set(id, board);
    return board;
  }

  async updateBoard(id: number, updates: Partial<InsertBoard>): Promise<Board | undefined> {
    const existing = this.boards.get(id);
    if (!existing) return undefined;
    
    const updated: Board = { ...existing, ...updates };
    this.boards.set(id, updated);
    return updated;
  }

  async deleteBoard(id: number): Promise<boolean> {
    return this.boards.delete(id);
  }

  async getAllBoards(): Promise<Board[]> {
    return Array.from(this.boards.values());
  }
}

export const storage = new MemStorage();
