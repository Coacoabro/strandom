import { pgTable, text, serial, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const boards = pgTable("boards", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  board: json("board").$type<string[][]>().notNull(),
  solutionWords: json("solution_words").$type<SolutionWord[]>().notNull(),
});

export const insertBoardSchema = createInsertSchema(boards).omit({
  id: true,
});

export type InsertBoard = z.infer<typeof insertBoardSchema>;
export type Board = typeof boards.$inferSelect;

export const solutionWordSchema = z.object({
  word: z.string(),
  path: z.array(z.tuple([z.number(), z.number()])),
});

export type SolutionWord = z.infer<typeof solutionWordSchema>;

export const boardDataSchema = z.object({
  title: z.string(),
  board: z.array(z.array(z.string())),
  solutionWords: z.array(solutionWordSchema),
});

export type BoardData = z.infer<typeof boardDataSchema>;
