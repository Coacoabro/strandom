# Word Search Puzzle Creator

## Overview

This is a full-stack web application for creating and managing word search puzzles. The application consists of a React frontend with a modern UI built using shadcn/ui components, and an Express.js backend with RESTful API endpoints. The system allows users to create word search boards, add words with visual path tracking, and manage puzzle data.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: React hooks with custom state management patterns
- **Data Fetching**: TanStack Query (React Query) for server state management

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Style**: RESTful JSON API
- **Validation**: Zod for runtime type validation and schema validation
- **Storage**: Drizzle ORM configured for PostgreSQL with in-memory fallback
- **Development**: Hot module reloading with Vite integration

### Key Components

#### Data Models
The application centers around a `Board` entity with the following structure:
- `id`: Auto-incrementing primary key
- `title`: Human-readable board name
- `board`: 2D array representing the letter grid (8x6 grid)
- `solutionWords`: Array of words with their corresponding paths on the grid

#### Frontend Components
- **BoardCreator**: Main page component for creating and editing puzzles
- **GridEditor**: Interactive grid component for placing letters and selecting word paths
- **Sidebar**: Control panel for managing board properties, words, and import/export
- **WordList**: Component for displaying and managing the list of solution words

#### Custom Hooks
- **useBoardEditor**: Central state management for board creation workflow
- **useToast**: Toast notification system
- **useMobile**: Responsive design helper

### Data Flow

1. **Board Creation**: Users can create new boards with custom titles
2. **Letter Placement**: Interactive grid allows clicking cells to input letters
3. **Word Path Selection**: Users can click and drag to select paths for solution words
4. **Word Validation**: Real-time validation ensures word paths are contiguous and valid
5. **Data Persistence**: Boards are saved via REST API to the backend storage system
6. **Import/Export**: JSON-based import/export functionality for board sharing

### External Dependencies

#### UI and Styling
- **Radix UI**: Provides accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **Lucide React**: Icon library

#### Data and State Management
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation for TypeScript

#### Backend Dependencies
- **Drizzle ORM**: Type-safe database toolkit
- **@neondatabase/serverless**: Serverless PostgreSQL adapter
- **connect-pg-simple**: PostgreSQL session store (configured but not actively used)

### Deployment Strategy

The application is configured for modern deployment patterns:

#### Development
- Vite dev server with HMR for frontend
- Express server with automatic restart via tsx
- Integrated development experience with proxy setup

#### Production Build
- Frontend builds to static assets in `dist/public`
- Backend builds to ESM bundle in `dist/index.js`
- Single-command deployment with `npm run build`
- Environment-based configuration for database connections

#### Database Strategy
- Primary: PostgreSQL via Drizzle ORM
- Fallback: In-memory storage for development/testing
- Schema migrations handled via `drizzle-kit`
- Environment variable configuration for database URL

The architecture prioritizes developer experience with hot reloading, type safety throughout the stack, and modern tooling while maintaining simplicity in deployment and data management.