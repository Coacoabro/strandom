import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Undo2, Redo2, Eraser, Info } from 'lucide-react';
import { Sidebar } from '@/components/sidebar';
import { GridEditor } from '@/components/grid-editor';
import { useBoardEditor } from '@/hooks/use-board-editor';
import { WORD_COLORS } from '@/lib/grid-utils';

export default function BoardCreator() {
  const {
    title,
    setTitle,
    grid,
    mode,
    setMode,
    words,
    isCreatingWord,
    currentPath,
    setCurrentPath,
    newWordText,
    canUndo,
    canRedo,
    handleCellClick,
    handleKeyPress,
    startWordCreation,
    completeWordCreation,
    cancelWordCreation,
    deleteWord,
    reorderWords,
    clearGrid,
    undo,
    redo,
    exportBoard,
    importBoard,
    getCellStyling
  } = useBoardEditor();

  const handleTestPuzzle = () => {
    if (words.length === 0) {
      alert('Add some words before testing the puzzle!');
      return;
    }
    
    // This would navigate to a test/preview mode
    alert('Test mode would be implemented here - showing the puzzle as players would see it');
  };

  return (
    <div className="min-h-screen flex">
      <Sidebar
        title={title}
        onTitleChange={setTitle}
        mode={mode}
        onModeChange={setMode}
        words={words}
        onAddWord={startWordCreation}
        onDeleteWord={deleteWord}
        onReorderWords={reorderWords}
        onImport={importBoard}
        onExport={exportBoard}
        onTestPuzzle={handleTestPuzzle}
        wordCount={words.length}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-slate-900">Grid Editor</h2>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!canUndo}
                  onClick={undo}
                >
                  <Undo2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!canRedo}
                  onClick={redo}
                >
                  <Redo2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearGrid}
                >
                  <Eraser className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="text-sm text-slate-500">
                Words: <span className="font-medium text-slate-900">{words.length}</span>
              </div>
              <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
              <span className="text-sm text-slate-600">Ready to export</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 overflow-auto">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Instructions */}
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>How to use the grid editor:</strong>
                <br />• <strong>Letters Mode:</strong> Click any cell and type a letter directly (or use Backspace to delete)
                <br />• <strong>Words Mode:</strong> Click cells in sequence to create word paths
                <br />• Letters can connect horizontally, vertically, or diagonally
                <br />• Click the same cell again to backtrack when creating paths
              </AlertDescription>
            </Alert>

            {/* Word Creation Status */}
            {isCreatingWord && (
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-slate-900">Creating word: {newWordText}</h3>
                      <p className="text-sm text-slate-500">
                        Click cells to create the path. Current path: {currentPath.length} cells
                        {currentPath.length > 0 && (
                          <span className="ml-2 text-slate-400">
                            • Click same cell to backtrack
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      {currentPath.length > 0 && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => setCurrentPath([])}
                        >
                          Clear Path
                        </Button>
                      )}
                      <Button variant="outline" size="sm" onClick={cancelWordCreation}>
                        Cancel
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={completeWordCreation}
                        disabled={currentPath.length < 2}
                      >
                        Complete Word
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Grid Editor */}
            <GridEditor
              onCellClick={handleCellClick}
              onKeyPress={handleKeyPress}
              grid={grid}
              getCellStyling={getCellStyling}
            />

            {/* Color Legend */}
            {words.length > 0 && (
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold text-slate-900 mb-4">Color Legend</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {words.map((word, index) => {
                      const color = WORD_COLORS[index % WORD_COLORS.length];
                      return (
                        <div key={word.id} className="flex items-center space-x-3">
                          <div className={`w-4 h-4 ${color.bg} ${color.border} border rounded`}></div>
                          <span className="text-sm text-slate-700">
                            {word.word}
                            {word.word.length >= 8 && (
                              <Badge variant="secondary" className="ml-2 text-xs">
                                Spangram
                              </Badge>
                            )}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
