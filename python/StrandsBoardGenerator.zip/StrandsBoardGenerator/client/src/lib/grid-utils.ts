export type GridPosition = [number, number];
export type GridCell = {
  letter: string;
  row: number;
  col: number;
  wordId?: string;
  color?: string;
};

export const GRID_ROWS = 8;
export const GRID_COLS = 6;

export const WORD_COLORS = [
  { name: 'green', bg: 'bg-green-100', border: 'border-green-400', text: 'text-green-700' },
  { name: 'blue', bg: 'bg-blue-100', border: 'border-blue-400', text: 'text-blue-700' },
  { name: 'red', bg: 'bg-red-100', border: 'border-red-400', text: 'text-red-700' },
  { name: 'orange', bg: 'bg-orange-100', border: 'border-orange-400', text: 'text-orange-700' },
  { name: 'purple', bg: 'bg-purple-100', border: 'border-purple-400', text: 'text-purple-700' },
  { name: 'cyan', bg: 'bg-cyan-100', border: 'border-cyan-400', text: 'text-cyan-700' },
  { name: 'amber', bg: 'bg-amber-100', border: 'border-amber-500', text: 'text-amber-700' },
  { name: 'yellow', bg: 'bg-yellow-100', border: 'border-yellow-400', text: 'text-yellow-700' },
  { name: 'pink', bg: 'bg-pink-100', border: 'border-pink-400', text: 'text-pink-700' },
  { name: 'indigo', bg: 'bg-indigo-100', border: 'border-indigo-400', text: 'text-indigo-700' },
];

export function createEmptyGrid(): string[][] {
  return Array(GRID_ROWS).fill(null).map(() => Array(GRID_COLS).fill(''));
}

export function isValidPosition(row: number, col: number): boolean {
  return row >= 0 && row < GRID_ROWS && col >= 0 && col < GRID_COLS;
}

export function isAdjacentPosition(pos1: GridPosition, pos2: GridPosition): boolean {
  const [r1, c1] = pos1;
  const [r2, c2] = pos2;
  const rowDiff = Math.abs(r1 - r2);
  const colDiff = Math.abs(c1 - c2);
  return rowDiff <= 1 && colDiff <= 1 && (rowDiff + colDiff > 0);
}

export function validateWordPath(path: GridPosition[], grid: string[][]): {
  isValid: boolean;
  word: string;
  errors: string[];
} {
  const errors: string[] = [];
  
  if (path.length < 2) {
    errors.push('Word must have at least 2 letters');
  }

  // Check if all positions are valid
  for (const [row, col] of path) {
    if (!isValidPosition(row, col)) {
      errors.push(`Invalid position: ${row}, ${col}`);
    }
  }

  // Check if path is connected (each cell should be adjacent to at least one other)
  for (let i = 1; i < path.length; i++) {
    if (!isAdjacentPosition(path[i - 1], path[i])) {
      errors.push(`Path not connected between positions ${i - 1} and ${i}`);
    }
  }

  // Build word from path and check for empty cells
  const letters: string[] = [];
  const emptyCells: number[] = [];
  
  path.forEach(([row, col], index) => {
    if (isValidPosition(row, col)) {
      const letter = grid[row][col];
      if (!letter || letter.trim() === '') {
        emptyCells.push(index + 1);
        letters.push('');
      } else {
        letters.push(letter);
      }
    } else {
      letters.push('');
    }
  });

  if (emptyCells.length > 0) {
    errors.push(`Path contains empty cells at position${emptyCells.length > 1 ? 's' : ''}: ${emptyCells.join(', ')}`);
  }

  const word = letters.join('');

  return {
    isValid: errors.length === 0,
    word: word.toUpperCase(),
    errors
  };
}

export function getWordColor(index: number): typeof WORD_COLORS[0] {
  return WORD_COLORS[index % WORD_COLORS.length];
}

export function exportBoardData(title: string, grid: string[][], solutionWords: any[]) {
  return {
    title,
    board: grid,
    solutionWords
  };
}

export function importBoardData(jsonData: string): any {
  try {
    const parsed = JSON.parse(jsonData);
    
    // Validate basic structure
    if (!parsed.title || !parsed.board || !parsed.solutionWords) {
      throw new Error('Invalid board format: missing required fields');
    }

    if (!Array.isArray(parsed.board) || parsed.board.length !== GRID_ROWS) {
      throw new Error(`Invalid board: must be ${GRID_ROWS} rows`);
    }

    for (let i = 0; i < parsed.board.length; i++) {
      if (!Array.isArray(parsed.board[i]) || parsed.board[i].length !== GRID_COLS) {
        throw new Error(`Invalid board: row ${i} must have ${GRID_COLS} columns`);
      }
    }

    if (!Array.isArray(parsed.solutionWords)) {
      throw new Error('Invalid board: solutionWords must be an array');
    }

    return parsed;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON format');
    }
    throw error;
  }
}
