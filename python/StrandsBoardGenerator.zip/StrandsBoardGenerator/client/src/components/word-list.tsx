import { Button } from '@/components/ui/button';
import { Trash2, Edit3, GripVertical } from 'lucide-react';
import { WordInProgress } from '@/hooks/use-board-editor';
import { useState } from 'react';

interface WordListProps {
  words: WordInProgress[];
  onDeleteWord: (wordId: string) => void;
  onReorderWords: (words: WordInProgress[]) => void;
}

export function WordList({ words, onDeleteWord, onReorderWords }: WordListProps) {
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [draggedOver, setDraggedOver] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent, wordId: string) => {
    setDraggedItem(wordId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, wordId: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDraggedOver(wordId);
  };

  const handleDragEnd = () => {
    setDraggedItem(null);
    setDraggedOver(null);
  };

  const handleDrop = (e: React.DragEvent, targetWordId: string) => {
    e.preventDefault();
    if (!draggedItem || draggedItem === targetWordId) return;

    const currentIndex = words.findIndex(w => w.id === draggedItem);
    const targetIndex = words.findIndex(w => w.id === targetWordId);
    
    const newWords = [...words];
    const [movedWord] = newWords.splice(currentIndex, 1);
    newWords.splice(targetIndex, 0, movedWord);
    
    onReorderWords(newWords);
    setDraggedItem(null);
    setDraggedOver(null);
  };

  return (
    <div className="space-y-2 max-h-80 overflow-y-auto">
      {words.map((word, index) => (
        <div
          key={word.id}
          draggable
          onDragStart={(e) => handleDragStart(e, word.id)}
          onDragOver={(e) => handleDragOver(e, word.id)}
          onDragEnd={handleDragEnd}
          onDrop={(e) => handleDrop(e, word.id)}
          className={`flex items-center justify-between p-3 rounded-lg border cursor-move transition-all ${
            draggedItem === word.id 
              ? 'opacity-50 scale-95' 
              : draggedOver === word.id 
                ? 'border-blue-400 bg-blue-50' 
                : 'bg-slate-50 hover:bg-slate-100'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <GripVertical className="h-4 w-4 text-slate-400" />
              <span className="text-xs text-slate-500 w-4">{index + 1}</span>
            </div>
            <div>
              <span className="font-medium text-slate-900">{word.word}</span>
              <div className="text-xs text-slate-500 mt-1">
                <span>{word.path.length} cells</span>
                {word.isComplete && (
                  <>
                    {' • '}
                    <span className="text-emerald-600">✓ Valid</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-primary-500 h-8 w-8 p-0"
            >
              <Edit3 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-red-500 h-8 w-8 p-0"
              onClick={() => onDeleteWord(word.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
      
      {words.length === 0 && (
        <div className="text-center py-8 text-slate-500">
          <p>No words added yet</p>
          <p className="text-sm">Add a word to get started</p>
        </div>
      )}
    </div>
  );
}
