import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Upload, Play, Download, Grid3X3 } from 'lucide-react';
import { WordList } from './word-list';
import { EditMode, WordInProgress } from '@/hooks/use-board-editor';

interface SidebarProps {
  title: string;
  onTitleChange: (title: string) => void;
  mode: EditMode;
  onModeChange: (mode: EditMode) => void;
  words: WordInProgress[];
  onAddWord: (word: string, isSpangram: boolean) => void;
  onDeleteWord: (wordId: string) => void;
  onReorderWords: (words: WordInProgress[]) => void;
  onImport: (jsonString: string) => void;
  onExport: () => void;
  onTestPuzzle: () => void;
  wordCount: number;
}

export function Sidebar({
  title,
  onTitleChange,
  mode,
  onModeChange,
  words,
  onAddWord,
  onDeleteWord,
  onReorderWords,
  onImport,
  onExport,
  onTestPuzzle,
  wordCount
}: SidebarProps) {
  const [isAddWordOpen, setIsAddWordOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [newWord, setNewWord] = useState('');

  const [importText, setImportText] = useState('');

  const handleAddWord = () => {
    if (newWord.trim()) {
      onAddWord(newWord.trim().toUpperCase(), false);
      setNewWord('');
      setIsAddWordOpen(false);
    }
  };

  const handleImport = () => {
    if (importText.trim()) {
      onImport(importText.trim());
      setImportText('');
      setIsImportOpen(false);
    }
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setImportText(content);
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="w-80 bg-white border-r border-slate-200 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary-500 rounded-lg flex items-center justify-center">
            <Grid3X3 className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Strands Creator</h1>
            <p className="text-sm text-slate-500">Build custom word puzzles</p>
          </div>
        </div>
      </div>

      {/* Board Settings */}
      <div className="p-6 space-y-6 flex-1 overflow-y-auto">
        {/* Title Input */}
        <div>
          <Label htmlFor="title" className="text-sm font-medium text-slate-700 mb-2 block">
            Puzzle Title
          </Label>
          <Input
            id="title"
            type="text"
            placeholder="It's a me!"
            value={title}
            onChange={(e) => onTitleChange(e.target.value)}
          />
        </div>

        {/* Current Mode */}
        <div>
          <Label className="text-sm font-medium text-slate-700 mb-3 block">
            Editing Mode
          </Label>
          <RadioGroup
            value={mode}
            onValueChange={(value) => onModeChange(value as EditMode)}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="letters" id="letters" />
              <Label htmlFor="letters" className="text-sm text-slate-700">
                Place Letters
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="words" id="words" />
              <Label htmlFor="words" className="text-sm text-slate-700">
                Create Word Paths
              </Label>
            </div>
          </RadioGroup>
        </div>

        {/* Word List */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <Label className="text-sm font-medium text-slate-700">
              Solution Words
            </Label>
            <Dialog open={isAddWordOpen} onOpenChange={setIsAddWordOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="px-3 py-1">
                  <Plus className="h-4 w-4 mr-1" />
                  Add
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Word</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="word" className="text-sm font-medium text-slate-700 mb-2 block">
                      Word
                    </Label>
                    <Input
                      id="word"
                      type="text"
                      placeholder="Enter word (e.g., MARIO)"
                      value={newWord}
                      onChange={(e) => setNewWord(e.target.value.toUpperCase())}
                    />
                  </div>
                  <p className="text-sm text-slate-500">
                    After adding the word, switch to "Create Word Paths" mode to draw the path on the grid. You can drag words in the list below to reorder them.
                  </p>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddWordOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddWord}>Add Word</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          <WordList words={words} onDeleteWord={onDeleteWord} onReorderWords={onReorderWords} />
        </div>

        {/* Actions */}
        <div className="space-y-3 pt-4 border-t border-slate-200">
          <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Upload className="h-4 w-4 mr-2" />
                Import JSON
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Import Board JSON</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="file-import" className="text-sm font-medium text-slate-700 mb-2 block">
                    Upload JSON File
                  </Label>
                  <Input
                    id="file-import"
                    type="file"
                    accept=".json"
                    onChange={handleFileImport}
                  />
                </div>
                <div>
                  <Label htmlFor="json-text" className="text-sm font-medium text-slate-700 mb-2 block">
                    Or paste JSON text
                  </Label>
                  <Textarea
                    id="json-text"
                    placeholder="Paste your board JSON here..."
                    value={importText}
                    onChange={(e) => setImportText(e.target.value)}
                    rows={10}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsImportOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleImport}>Import</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Button variant="outline" className="w-full" onClick={onTestPuzzle}>
            <Play className="h-4 w-4 mr-2" />
            Test Puzzle
          </Button>

          <Button className="w-full" onClick={onExport}>
            <Download className="h-4 w-4 mr-2" />
            Export JSON
          </Button>
        </div>
      </div>
    </div>
  );
}
