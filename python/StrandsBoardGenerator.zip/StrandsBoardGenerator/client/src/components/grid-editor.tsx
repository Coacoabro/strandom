import { cn } from '@/lib/utils';
import { useBoardEditor } from '@/hooks/use-board-editor';

interface GridEditorProps {
  onCellClick: (row: number, col: number) => void;
  onKeyPress: (row: number, col: number, key: string) => void;
  grid: string[][];
  getCellStyling: (row: number, col: number) => {
    background: string;
    border: string;
    text: string;
    extra?: string;
  };
}

export function GridEditor({ onCellClick, onKeyPress, grid, getCellStyling }: GridEditorProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
      <div className="flex items-center justify-center">
        <div className="grid grid-rows-8 grid-cols-6 gap-1 p-4 bg-slate-50 rounded-lg">
          {grid.map((row, rowIndex) =>
            row.map((letter, colIndex) => {
              const styling = getCellStyling(rowIndex, colIndex);
              return (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  className={cn(
                    "w-16 h-16 rounded-lg flex items-center justify-center cursor-pointer transition-all duration-200 group focus:outline-none focus:ring-2 focus:ring-blue-400",
                    styling.background,
                    styling.border,
                    styling.extra
                  )}
                  tabIndex={0}
                  onClick={() => onCellClick(rowIndex, colIndex)}
                  onKeyDown={(e) => {
                    if (e.key.length === 1 && /^[A-Za-z]$/.test(e.key)) {
                      e.preventDefault();
                      onKeyPress(rowIndex, colIndex, e.key);
                    } else if (e.key === 'Backspace' || e.key === 'Delete') {
                      e.preventDefault();
                      onKeyPress(rowIndex, colIndex, '');
                    }
                  }}
                >
                  <span className={cn("text-xl font-bold", styling.text)}>
                    {letter || ""}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
