import { useState, useCallback, useRef } from 'react';
import { SolutionWord, BoardData } from '@shared/schema';
import { GridPosition, createEmptyGrid, validateWordPath, getWordColor, GRID_ROWS, GRID_COLS } from '@/lib/grid-utils';
import { useToast } from '@/hooks/use-toast';

export type EditMode = 'letters' | 'words';

export interface WordInProgress extends SolutionWord {
  id: string;
  color: typeof import('@/lib/grid-utils').WORD_COLORS[0];
  isComplete: boolean;
}

export function useBoardEditor() {
  const { toast } = useToast();
  
  // Basic state
  const [title, setTitle] = useState('New Puzzle');
  const [grid, setGrid] = useState<string[][]>(createEmptyGrid);
  const [mode, setMode] = useState<EditMode>('letters');
  const [words, setWords] = useState<WordInProgress[]>([]);
  
  // Word creation state
  const [isCreatingWord, setIsCreatingWord] = useState(false);
  const [currentPath, setCurrentPath] = useState<GridPosition[]>([]);
  const [newWordText, setNewWordText] = useState('');
  const [isSpangram, setIsSpangram] = useState(false);
  
  // History for undo/redo
  const [history, setHistory] = useState<{ grid: string[][]; words: WordInProgress[] }[]>([
    { grid: createEmptyGrid(), words: [] }
  ]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  // Refs
  const gridRef = useRef<HTMLDivElement>(null);

  // Save state to history
  const saveToHistory = useCallback(() => {
    const newState = { grid: JSON.parse(JSON.stringify(grid)), words: JSON.parse(JSON.stringify(words)) };
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newState);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [grid, words, history, historyIndex]);

  // Handle key press for letter input
  const handleKeyPress = useCallback((row: number, col: number, key: string) => {
    if (mode === 'letters') {
      saveToHistory();
      setGrid(prev => {
        const newGrid = [...prev];
        newGrid[row] = [...newGrid[row]];
        if (key === '' || key === 'Backspace' || key === 'Delete') {
          // Clear the cell
          newGrid[row][col] = '';
        } else if (/^[A-Za-z]$/.test(key)) {
          // Set the letter
          newGrid[row][col] = key.toUpperCase();
        }
        return newGrid;
      });
    }
  }, [mode, saveToHistory]);

  // Handle cell click
  const handleCellClick = useCallback((row: number, col: number) => {
    if (mode === 'words' && isCreatingWord) {
      // Word path creation mode
      const newPos: GridPosition = [row, col];
      
      // Check if the cell has a letter
      if (!grid[row][col]) {
        toast({
          title: "Empty Cell",
          description: "Please place a letter in this cell first (switch to Letters mode)",
          variant: "destructive"
        });
        return;
      }
      
      if (currentPath.length === 0) {
        setCurrentPath([newPos]);
      } else {
        const isDuplicate = currentPath.some(([r, c]) => r === row && c === col);
        
        if (isDuplicate) {
          // Remove this position and all after it (allows "unchecking")
          const index = currentPath.findIndex(([r, c]) => r === row && c === col);
          setCurrentPath(prev => prev.slice(0, index + 1));
        } else {
          // Check if adjacent to any position in the current path
          const canConnect = currentPath.some(([r, c]) => {
            const rowDiff = Math.abs(r - row);
            const colDiff = Math.abs(c - col);
            return rowDiff <= 1 && colDiff <= 1;
          });
          
          if (canConnect) {
            setCurrentPath(prev => [...prev, newPos]);
          } else {
            toast({
              title: "Invalid Connection",
              description: "Letters must be adjacent to the current path (horizontal, vertical, or diagonal)",
              variant: "destructive"
            });
          }
        }
      }
    }
  }, [mode, isCreatingWord, currentPath, grid, saveToHistory, toast]);

  // Start creating a new word
  const startWordCreation = useCallback((wordText: string, spangram: boolean = false) => {
    if (!wordText.trim()) {
      toast({
        title: "Invalid Word",
        description: "Please enter a word",
        variant: "destructive"
      });
      return;
    }

    setNewWordText(wordText.toUpperCase());
    setIsSpangram(spangram);
    setIsCreatingWord(true);
    setCurrentPath([]);
    setMode('words');
  }, [toast]);

  // Complete word creation
  const completeWordCreation = useCallback(() => {
    if (currentPath.length < 2) {
      toast({
        title: "Invalid Path",
        description: "Word must have at least 2 letters",
        variant: "destructive"
      });
      return;
    }

    const validation = validateWordPath(currentPath, grid);
    
    if (!validation.isValid) {
      toast({
        title: "Invalid Path",
        description: validation.errors.join(', '),
        variant: "destructive"
      });
      return;
    }

    if (validation.word !== newWordText) {
      toast({
        title: "Word Mismatch",
        description: `Path spells "${validation.word}" but expected "${newWordText}"`,
        variant: "destructive"
      });
      return;
    }

    saveToHistory();
    
    const newWord: WordInProgress = {
      id: `word-${Date.now()}`,
      word: newWordText,
      path: [...currentPath],
      color: getWordColor(words.length),
      isComplete: true
    };

    setWords(prev => [...prev, newWord]);
    setIsCreatingWord(false);
    setCurrentPath([]);
    setNewWordText('');
    setIsSpangram(false);

    toast({
      title: "Word Added",
      description: `"${newWordText}" has been added to the puzzle`,
    });
  }, [currentPath, grid, newWordText, words.length, saveToHistory, toast]);

  // Cancel word creation
  const cancelWordCreation = useCallback(() => {
    setIsCreatingWord(false);
    setCurrentPath([]);
    setNewWordText('');
    setIsSpangram(false);
  }, []);

  // Delete word
  const deleteWord = useCallback((wordId: string) => {
    saveToHistory();
    setWords(prev => prev.filter(w => w.id !== wordId));
    
    toast({
      title: "Word Deleted",
      description: "Word has been removed from the puzzle",
    });
  }, [saveToHistory, toast]);

  // Reorder words
  const reorderWords = useCallback((newWords: WordInProgress[]) => {
    saveToHistory();
    setWords(newWords);
  }, [saveToHistory]);

  // Clear grid
  const clearGrid = useCallback(() => {
    if (confirm('Are you sure you want to clear the entire grid?')) {
      saveToHistory();
      setGrid(createEmptyGrid());
      setWords([]);
    }
  }, [saveToHistory]);

  // Undo
  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const prevState = history[historyIndex - 1];
      setGrid(prevState.grid);
      setWords(prevState.words);
      setHistoryIndex(historyIndex - 1);
    }
  }, [history, historyIndex]);

  // Redo
  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const nextState = history[historyIndex + 1];
      setGrid(nextState.grid);
      setWords(nextState.words);
      setHistoryIndex(historyIndex + 1);
    }
  }, [history, historyIndex]);

  // Export board data
  const exportBoard = useCallback(() => {
    const solutionWords = words.map(w => ({
      word: w.word,
      path: w.path
    }));

    const boardData: BoardData = {
      title,
      board: grid,
      solutionWords
    };

    const dataStr = JSON.stringify(boardData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title.toLowerCase().replace(/\s+/g, '-')}.json`;
    link.click();
    
    URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "Board has been exported as JSON",
    });
  }, [title, grid, words, toast]);

  // Import board data
  const importBoard = useCallback((jsonString: string) => {
    try {
      const boardData = JSON.parse(jsonString) as BoardData;
      
      // Validate structure
      if (!boardData.title || !boardData.board || !boardData.solutionWords) {
        throw new Error('Invalid board format');
      }

      if (boardData.board.length !== GRID_ROWS || 
          !boardData.board.every(row => row.length === GRID_COLS)) {
        throw new Error(`Board must be ${GRID_ROWS}x${GRID_COLS}`);
      }

      saveToHistory();
      
      setTitle(boardData.title);
      setGrid(boardData.board);
      
      const importedWords: WordInProgress[] = boardData.solutionWords.map((w, index) => ({
        id: `imported-${index}`,
        word: w.word,
        path: w.path,
        color: getWordColor(index),
        isComplete: true
      }));
      
      setWords(importedWords);

      toast({
        title: "Import Successful",
        description: `Loaded "${boardData.title}" with ${boardData.solutionWords.length} words`,
      });
    } catch (error) {
      toast({
        title: "Import Failed",
        description: error instanceof Error ? error.message : "Invalid JSON format",
        variant: "destructive"
      });
    }
  }, [saveToHistory, toast]);

  // Get cell styling
  const getCellStyling = useCallback((row: number, col: number) => {
    // Check if cell is part of any word
    const wordForCell = words.find(w => 
      w.path.some(([r, c]) => r === row && c === col)
    );
    
    // Check if cell is in current path
    const currentPathIndex = currentPath.findIndex(([r, c]) => r === row && c === col);
    const isInCurrentPath = currentPathIndex !== -1;
    
    if (isInCurrentPath) {
      return {
        background: 'bg-blue-200',
        border: 'border-blue-500 border-3 shadow-lg',
        text: 'text-blue-800 font-bold',
        extra: currentPathIndex === 0 ? 'ring-2 ring-green-400' : currentPathIndex === currentPath.length - 1 ? 'ring-2 ring-orange-400' : ''
      };
    }
    
    if (wordForCell) {
      return {
        background: wordForCell.color.bg,
        border: `${wordForCell.color.border} border-2`,
        text: wordForCell.color.text,
        extra: ''
      };
    }
    
    // Empty cell styling
    const isEmpty = !grid[row][col];
    return {
      background: isEmpty ? 'bg-slate-100' : 'bg-white',
      border: isEmpty ? 'border-slate-200 border-2 hover:border-blue-300' : 'border-slate-300 border-2 hover:border-primary-400',
      text: isEmpty ? 'text-slate-400' : 'text-slate-800 group-hover:text-primary-600',
      extra: ''
    };
  }, [words, currentPath, grid]);

  return {
    // State
    title,
    setTitle,
    grid,
    mode,
    setMode,
    words,
    isCreatingWord,
    currentPath,
    setCurrentPath,
    newWordText,
    isSpangram,
    canUndo: historyIndex > 0,
    canRedo: historyIndex < history.length - 1,
    
    // Actions
    handleCellClick,
    handleKeyPress,
    startWordCreation,
    completeWordCreation,
    cancelWordCreation,
    deleteWord,
    reorderWords,
    clearGrid,
    undo,
    redo,
    exportBoard,
    importBoard,
    getCellStyling,
    
    // Refs
    gridRef
  };
}
